import { Injectable } from '@angular/core';
import { CadastroUsuario } from './cadastro-usuario';
import { BehaviorSubject } from 'rxjs';
import { AngularFireDatabase } from '@angular/fire/database';

@Injectable({
  providedIn: 'root'
})
export class CadastroUsuarioService {

  constructor(private db: AngularFireDatabase) { }

    insert(cadUsu: CadastroUsuario){
     this.db.list('cadUsu').push(cadUsu)
     .then((result: any) =>{
      console.log(result.key);
    });
   }

  // private cadUsuSource = new BehaviorSubject({
  //   cadUsu: null, key: ''
  // });
  // currentCadUsu = this.cadUsuSource.asObservable();

  

  // changeContato(cadUsu: CadastroUsuario, key: string){
  //   this.cadUsuSource.next({
  //     cadUsu: cadUsu, key: key
  //   })
  // }

  getEstados(){
    return['AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF',
  'ES', 'GO', 'MA', 'MT', 'MS', 'MG', 'PA', 'PB',
'PR', 'PE', 'PI', 'RJ', 'RN', 'RS', 'RO', 'RR',
',SC', 'SP', 'SE', 'TO'];
  }
}
     