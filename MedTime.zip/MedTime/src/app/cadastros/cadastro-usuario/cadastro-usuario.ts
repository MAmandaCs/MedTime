export class CadastroUsuario {

    nome: string = '';
    telefone: string = '';
    rg: string = '';
    cpf: string = '';
    email: string = '';
    senha: string = '';
    confSenha: string = '';
    bairro: string = '';
    rua: string = '';
    cidade: string = '';
    
}
