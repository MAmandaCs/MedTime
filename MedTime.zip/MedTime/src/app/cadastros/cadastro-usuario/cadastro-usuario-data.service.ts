import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { CadastroUsuario } from './cadastro-usuario';

@Injectable({
  providedIn: 'root'
})
export class CadastroUsuarioDataService {

  private cadUsuSource = new BehaviorSubject({
    cadUsu: null, key: ''
  });

  constructor() { }

  changeCadastroUsuario(cadUsu: CadastroUsuario, key: string){
    this.cadUsuSource.next({cadUsu: cadUsu, key: key});
  }
}
