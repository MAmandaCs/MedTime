import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { CadastroUsuarioService } from './cadastro-usuario.service';
import { AngularFireDatabase } from '@angular/fire/database';
import { CadastroUsuario } from 'src/app/cadastros/cadastro-usuario/cadastro-usuario';
import { CadastroUsuarioDataService } from './cadastro-usuario-data.service';

@Component({
  selector: 'app-cadastro-usuario',
  templateUrl: './cadastro-usuario.component.html',
  styleUrls: ['./cadastro-usuario.component.css']
})
export class CadastroUsuarioComponent implements OnInit {

  cadUsu: CadastroUsuario;
  key: string = '';
  

  constructor(private db: AngularFireDatabase,
    private cadUsuService: CadastroUsuarioService,
    private cadUsuDataService: CadastroUsuarioDataService) {
   
   }

   insert(cadUsu: CadastroUsuario){
    this.db.list('cadUsu').push(cadUsu)
    .then((result: any) =>{
     console.log(result.key);
   });
  }

  ngOnInit() {

    this.cadUsu = new CadastroUsuario();

  }

  onSubmit(){
    if(this.key){

    }else{
      this.insert(this.cadUsu);
    }
    this.cadUsu = new CadastroUsuario();
  }
}
