import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { CadastroPaciente } from './cadastro-paciente';

@Injectable({
  providedIn: 'root'
})
export class CadastroPacienteService {

  insert(cadPac: CadastroPaciente) {
    throw new Error("Method not implemented.");
  }

  private cadPacSource = new BehaviorSubject({
    cadPac: null, key: ''
  });

  constructor() { }

  changeCadastroUsuario(cadPac: CadastroPaciente, key: string){
    this.cadPacSource.next({cadPac: cadPac, key: key})
  }
}
