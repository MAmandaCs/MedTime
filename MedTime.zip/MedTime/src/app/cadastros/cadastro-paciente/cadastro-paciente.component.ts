import { Component, OnInit } from '@angular/core';
import { CadastroPaciente } from './cadastro-paciente';
import { AngularFireDatabase } from '@angular/fire/database';
import { CadastroPacienteDataService } from './cadastro-paciente-data.service';
import { CadastroPacienteService } from './cadastro-paciente.service';


@Component({
  selector: 'app-cadastro-paciente',
  templateUrl: './cadastro-paciente.component.html',
  styleUrls: ['./cadastro-paciente.component.css']
})
export class CadastroPacienteComponent implements OnInit {

  cadastroPaciente: CadastroPaciente;
  key: string = '';

  constructor(private db: AngularFireDatabase,
    private cadPacService: CadastroPacienteService,
    private cadPacDataService: CadastroPacienteDataService) {
     }

    insert(cadPac: CadastroPaciente){
      this.db.list('cadastroPaciente').push(cadPac)
      .then((result: any) =>{
        console.log(result.key);
      });
    }

  ngOnInit() {
    this.cadastroPaciente = new CadastroPaciente();
  }

  onSubmit(){
    if(this.key){

    }else{
      this.insert(this.cadastroPaciente);
    }
    this.cadastroPaciente = new CadastroPaciente();
  }

}
