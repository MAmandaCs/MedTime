export class CadastroPaciente {

    nome: String = '';
    telefone: String = '';
    rg: String = '';
    cpf: String = '';
    email: String = '';
    senha: String = '';
    confSenha: String = '';
    bairro: String = '';
    rua: String = '';
    cidade: String = '';

    // constructor (nome: string, telefone: string, rg: string, cpf: string, email: string, 
    //     senha: string, confSenha: string, bairro: string, rua: string, cidade: string){
    //         this.nome = nome;
    //         this.telefone = telefone;
    //         this.rg = rg;
    //         this.cpf = cpf;
    //         this.email = email;
    //         this.senha = senha;
    //         this.confSenha = confSenha;
    //         this.bairro = bairro;
    //         this.rua = rua;
    //         this.cidade = cidade;

    
    
}
