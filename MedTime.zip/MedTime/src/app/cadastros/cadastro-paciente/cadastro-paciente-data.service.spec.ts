import { TestBed } from '@angular/core/testing';

import { CadastroPacienteDataService } from './cadastro-paciente-data.service';

describe('CadastroPacienteDataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CadastroPacienteDataService = TestBed.get(CadastroPacienteDataService);
    expect(service).toBeTruthy();
  });
});
