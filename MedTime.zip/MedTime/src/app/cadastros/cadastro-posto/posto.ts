export class Posto {
// tslint:disable-next-line: ban-types
nome: String;
}
