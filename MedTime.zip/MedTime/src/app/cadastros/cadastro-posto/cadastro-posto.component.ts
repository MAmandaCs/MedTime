import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cadastro-posto',
  templateUrl: './cadastro-posto.component.html',
  styleUrls: ['./cadastro-posto.component.css']
})
export class CadastroPostoComponent implements OnInit {

  constructor() { }


  ngOnInit() {
  }

}
