import { Posto } from './posto';

describe('Posto', () => {
  it('should create an instance', () => {
    expect(new Posto()).toBeTruthy();
  });
});
