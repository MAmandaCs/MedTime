import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-meus-dados',
  templateUrl: './meus-dados.component.html',
  styleUrls: ['./meus-dados.component.css']
})
export class MeusDadosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
alerta() {
  alert('deseja excluir esse perfil?');
}
}
