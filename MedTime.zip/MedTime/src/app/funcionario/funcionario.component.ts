import { Component, OnInit } from '@angular/core';
declare var $: any;
@Component({
  selector: 'app-funcionario',
  templateUrl: './funcionario.component.html',
  styleUrls: ['./funcionario.component.css']
})
export class FuncionarioComponent implements OnInit {
  pacientes: any;
  pacienteSelecionado: any;
  Vipacientes: any;
  constructor() {
  this.pacientes = [{nome: 'Álvaro Kayc da Silva Santos', cpf: '122365474-09' }];
  this.pacienteSelecionado = {};
  // tslint:disable-next-line: max-line-length
  this.Vipacientes = [{prontuario: '11122251', nome: 'Estephany Beatriz da Silva Santos', cpf: '11111111111-11',
  nascimento: '12/12/19', email: 'estephany@gmail.com', endereco: 'Rua Epitacio Coimbra, nº 1042. Heliópolis'}];
  }  ngOnInit(): void {
    setTimeout(() => {
      // tslint:disable-next-line: only-arrow-functions
            $(document).ready( function() {
              $('.collapsible').collapsible();
            });
}, 100);
}
selecionarPaciente(paciente) {
  this.pacienteSelecionado = paciente;
 }

}

