import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pre-natal',
  templateUrl: './pre-natal.component.html',
  styleUrls: ['./pre-natal.component.css']
})
export class PreNatalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
