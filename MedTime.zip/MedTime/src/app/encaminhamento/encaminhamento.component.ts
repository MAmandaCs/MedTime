import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-encaminhamento',
  templateUrl: './encaminhamento.component.html',
  styleUrls: ['./encaminhamento.component.css']
})
export class EncaminhamentoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
