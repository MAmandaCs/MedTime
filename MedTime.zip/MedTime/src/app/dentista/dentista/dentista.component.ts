import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dentista',
  templateUrl: './dentista.component.html',
  styleUrls: ['./dentista.component.css']
})
export class DentistaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
