import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clinico',
  templateUrl: './clinico.component.html',
  styleUrls: ['./clinico.component.css']
})
export class ClinicoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
