export const environment = {
  production: false,

  firebase: {
    apiKey: "AIzaSyB0HJKAxF3kBoPgy0VKluHDcYy66W3fvNM",
    authDomain: "medtime-3c1ae.firebaseapp.com",
    databaseURL: "https://medtime-3c1ae.firebaseio.com",
    projectId: "medtime-3c1ae",
    storageBucket: "medtime-3c1ae.appspot.com",
    messagingSenderId: "420939110433",
    appId: "1:420939110433:web:4328c519796abcb1"
  }
};

